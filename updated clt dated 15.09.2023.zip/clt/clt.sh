#!/bin/bash

    # Color variables
    red='\033[0;31m'
    green='\033[0;32m'
    yellow='\033[0;33m'
    
    # Clear the color after that
    clear='\033[0m'

#--------------------------------Welcome--------------------------------#
function welcome
{
	clear
	echo "---------------------------------------------------------"
	echo "|    Welcome To Command Line Test By Babu Malagaveli    |"
	echo "---------------------------------------------------------"
	echo "Login/Register"
	echo "1. Sign in"
	echo "2. Sign up"
	echo "3. Exit"
	echo "Note: Script Exit on Timeout."
	echo
	echo
	echo -e "${red}Instructions: Please clear the contents of the below files before you attempt the test!${clear}"
	echo -e "${green}1.result.txt${clear}"
	echo -e "${green}2.user_answer.txt${clear}"
	echo
	read -p "Please choose your option: " opt
	if [[ $opt -eq 1 ]]
	then
		sign_in
	else
		if [[ $opt -eq 2 ]]
		then
			sign_up
		else
			if [[ $opt -eq 3 ]]
			then
				exit 0
			else
				echo "Invalid Option. Choose a correct option..."
				welcome
			fi
		fi
	fi
}

#--------------------------------Creating user.csv && password.csv--------------------------------#

	if [ ! -f "user.csv" ]                 # check if user.csv file exists 
    then
        touch user.csv
    fi

    if [ ! -f "password.csv" ]                # check if password.csv file exists
    then
        touch password.csv
    fi

#--------------------------------Sign Up--------------------------------#

function sign_up
{
	clear
	echo "------------------------------------------------"
	echo "                   Sign up                    |"
	echo "------------------------------------------------"
	read -p "Enter the username: " user       # read username
    unames=(`cat user.csv`)                   # store all usernames from user file to array
    unames_len=${#unames[@]}
    flag=1
    for i in `seq 0 $(($unames_len-1))`       # loop to validate if entered username already exists or not
    do
    if [ $user = ${unames[$i]} ]
    then
        flag=0
    fi
    done

    if [ $flag -eq 1 ]                        # if username does not exist request password from user
    then
        read -sp "Enter your password: " pass1
        echo
        read -sp "Confirm your password: " pass2
		if [ $pass1 = $pass2 ]               # check for password confirmation
	    	then
			echo $user >> user.csv                                    # save user to user.csv file
			echo $pass2 | base64 >> password.csv                      # save encoded password in password.csv file
			echo -e "\nUser registration succesfull!!!"
				sleep 1
				iloading
				#sign_in
                welcome
	    	else
			echo -e "\nPassword mismatch! Please enter correct password"   # check for password mismatch & return to start menu
	        	
            read -sp "Again Confirm your password: " pass2

		if [ $pass1 = $pass2 ]               # check for password confirmation
	    	then
			echo $user >> user.csv                                    # save user to user.csv file
			echo $pass2 | base64 >> password.csv                      # save encoded password in password.csv file
			echo -e "\nUser registration succesfull!!!"
				sleep 1
				iloading
				#sign_in
                welcome
	    	else
			echo -e "\nPassword mismatch! Aborted"   # check for password mismatch & return to start menu
        fi
    fi
    else
        echo "The $user username is already present"                  # check if user is available & return to start menu
        echo "Kindly Sign in to proceed."
		sleep 1
		iloading
		sign_in

    fi
}
#--------------------------------authenticate_--------------------------------#

function authenticate_
{	
	#clear
	echo "------------------------------------------------"
	echo "         Welcome to your Test $user         "
	echo "------------------------------------------------"
	echo "1. Take Test"
	echo "2. View Test"
	echo "3. Back"
	read -p "Please choose your option: " op
	if [[ $op -eq 1 ]]
	then
		take_test
	else
		if [[ $op -eq 2 ]]
		then
			view_test
		else
			if [[ $op -eq 3 ]]
			then
				welcome
			else
				echo "Invalid Option. Try Again..."
				sleep 1
				authenticate_
			fi
		fi
	fi
}
#--------------------------------Sign in--------------------------------#

function sign_in
{
	#clear
	echo
	echo "------------------------------------------------"
	echo "                   Sign in                    |"
	echo "------------------------------------------------"

	read -p "Enter the username: " user                        # read the username

    uname=(`cat user.csv`)                                     # retrieve all username and store in array
    uname_len=${#uname[@]}
    pass=(`cat password.csv`)                                  # retrieve all password in encoded format and store in array
    index=""
    for i in `seq 0 $(($uname_len-1))`                         # loop to find if entered username is present in user.csv file                       
    do
    	if [ "$user" = "${uname[$i]}" ]
    	then
            index=$i                                           # save index value of the username matched in file
        fi
    done
    if [ -n "$index" ]                                         # check if index variable is not null meaning user is present
    then
        echo "Username Matched!!!"
        read -sp "Enter your password: " pass1                                               # read password from user
	else
		echo "You are not signed up."
		echo "Please Sign up."
		iloading
		sign_up
	fi

        if [ $pass1 = `echo ${pass[$index]} | base64 --decode` ]    # check if correct password is entered after decoding it from password.csv file
        then
            check=1
            echo -e "\nPassword Matched."
            echo "Signed in successfully!!!"
			sleep 2
			authenticate_
		else
			echo -e "\nPlease enter the correct Password.Try again..."
			iloading
			sleep 1
			sign_in
		fi
			

}



#--------------------------------Take Test--------------------------------#

function take_test
{	
	clear
	qbank_lines=`cat questionbank.txt | wc -l`      # store number of lines in question bank file
    for i in `seq 5 5 $qbank_lines`                 # loop to iterate through the question set each of five lines
    do
        clear
        cat questionbank.txt | head -$i | tail -5   # display the question
        for j in `seq 10 -1 1`                      # loop to iterate 10 times in reverse
        do
            echo -e "\r Enter the choice :\e[31m$j \e[0m \c"    # intializing 10 second counter for user to provide the option

            read -t 1 option

            if [ -z "$option" ]                     # check if no option is selection means timeout
            then
                option="e"
            else
                break                               # else break the inner loop:
            fi
        done
        echo $option >> user_answer.txt             # store option in a temporary file
        echo "-------------------------"
    done
    clear          
    user_ans=(`cat user_answer.txt`)                # store user selected option in an array
    crrt_ans=(`cat correctanswer.txt`)              # store all the correct answers in an array
    uans_len=${#user_ans[@]}
    for i in `seq 0 $(($uans_len-1))`               # loop to check and compare the correct answers ans store in result.txt file
    do
    if [ "${user_ans[i]}" = "${crrt_ans[i]}" ]
       
  	then
            echo "correct" >> result.txt
        elif [ ${user_ans[$i]} = "e" ]              #check if the option is e which means not answered
        then
            echo "timeout" >> result.txt
        else
            echo "wrong" >> result.txt
        fi
    done
	loading
	echo -e "The exam was successfully completed!\nThank you"
	authenticate_
}


#--------------------------------View Test--------------------------------#

function view_test
{	
	
    #find the marks 
    total=10
    obt_marks=0
    user_ans=(`cat user_answer.txt`)                # store user selected option in an array
    crrt_ans=(`cat correctanswer.txt`)              # store all the correct answers in an array
    uans_len=${#user_ans[@]}
    result=(`cat result.txt`)              # store all the correct answers in an array
    

    
	qbank_lines=`cat questionbank.txt | wc -l`      # store number of lines in question bank file
    for i in `seq 5 5 $qbank_lines`                 # loop to iterate through the question set each of five lines
    do
        cat questionbank.txt | head -$i | tail -5   # display the question
        
        for i in `seq 0 $(($uans_len-1))`               # loop to print the feedback from result.txt file
        do
            if [ "${result[$i]}" = "correct" ]
		then
		echo
                echo -e "${green}${result[$i]}${clear}"
             	echo
   		break
	    elif [ "${result[$i]}" = "wrong" ]
		then
		echo
                echo -e "${red}${result[$i]}${clear}"
             	echo
   		break
	    else
		echo -e "${yellow}${result[$i]}${clear}"
             	echo
   		break
	    fi
        done
    done

    for i in `seq 0 $(($uans_len-1))`               # loop to check and compare the correct answers ans store in result.txt file
    do
        if [ ${result[$i]} = "correct" ]    #compare if two strings are equal
        then
            obt_marks=$(($obt_marks+1))
       fi
   done
        echo
        echo -e "marks obtained = $obt_marks/$total "
	authenticate_
}


#--------------------------------Infinite Loading--------------------------------#

function iloading
{
	while true;
	do
    	# Frame #1
    	printf "\r< Loading." 
    	sleep 0.5
    	# Frame #2 
    	printf "\r> Loading.." 
    	sleep 0.5 
		# Frame #3
    	printf "\r> Loading..." 
    	sleep 0.5
		break
	done
}

#--------------------------------Loading--------------------------------#

function loading
{
	clear
	echo "loading"
	sleep 0.5
	clear
	echo "loading."
	sleep 0.5
	clear
	echo "loading.."
	sleep 0.5
	clear
	echo "loading..."
	sleep 0.5
	clear
}

#--------------------------------Countdown--------------------------------#
	
function countdown
{
 hour=00
 min=00
 sec=10
        while [ $hour -ge 0 ]; do
                 while [ $min -ge 0 ]; do
                         while [ $sec -ge 0 ]; do
                                 echo -ne "$hour:$min:$sec\033[0K\r"
                                 let "sec=sec-1"
                                 sleep 1
                         done
                         sec=59
                         let "min=min-1"
                 done
                 min=59
                 let "hour=hour-1"
         done
}

#--------------------------------Main function where function calls happen--------------------------------#

welcome

